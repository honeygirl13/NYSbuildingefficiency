Use buildings;
Select * 
from one_;
Select one_.*,two_.*
from one_ 
Join two_ 
On one_.facility_name = two_.facility_name;
Select one_.*,three_.*
from one_
Join three_
On one_.facility_name = three_.facility_name;
Select one_.*,four_.*
from one_
Join four_
On one_.facility_name = four_.facility_name;
Select one_.*,five_.*
from one_
Join five_
On one_.facility_name = five_.facility_name;
Select one_.*,six_.*
from one_
Join six_
On one_.facility_name = six_.facility_name;
Select one_.*,seven_.*
from one_
Join seven_
On one_.facility_name = seven_.facility_name;
Select one_.*,eight_.*
from one_
Join eight_
On one_.facility_name = eight_.facility_name;